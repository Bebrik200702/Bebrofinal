import numpy as np
import torch
from torch import nn
from copy import deepcopy

class WordBaseMLMDataCollator():
    def __init__(self,tokenizer,mlm_prob=0.15, max_length=70,min_mask=1,max_mask=0.5):
        self.tokenizer = tokenizer
        self.mlm_prob = mlm_prob
        self.max_length = max_length
        self.mask_token = self.tokenizer.mask_token
        self.mask_id = self.tokenizer.encode(self.mask_token,add_special_tokens=False)[0]
        self.min_mask = min_mask
        self.max_mask = max_mask
    
    def build_prob_mask_words(self,words):
        max_tokens = len(words) * self.max_mask
        prob_mask = np.random.random(len(words))
        sm = (prob_mask <= self.mlm_prob).sum()
        while (sm < self.min_mask) or (sm > max_tokens):
            prob_mask = np.random.random(len(words))
            sm = (prob_mask <= self.mlm_prob).sum()
        return prob_mask < self.mlm_prob

    
    def __call__(self,walk):
        labels = ' '.join(walk)
        inputs = ''
        prob_mask = self.build_prob_mask_words(walk)
        
        for word,p in zip(walk,prob_mask):
            if p:
                num_tokens = len(self.tokenizer.encode(word,add_special_tokens=False))
                inputs += ' '.join([self.mask_token] * num_tokens)
            else:
                inputs += (' ' + word)
        
        inputs_encode = self.tokenizer.encode_plus(
            inputs,
            max_length=self.max_length,
            truncation=False,
            padding='max_length',
            return_tensors='pt'
        )
        
        labels_encode = self.tokenizer.encode_plus( 
            labels,
            max_length=self.max_length,
            truncation=False,
            padding='max_length',
            return_tensors='pt'
        )
        
        attn_mask = inputs_encode['attention_mask'].squeeze(0)
        inputs = inputs_encode['input_ids'].squeeze(0)
        labels = labels_encode['input_ids'].squeeze(0)
        assert len(inputs) == len(labels)
        
        labels[inputs != self.mask_id] = -100
        
        return {
            'input_ids':inputs,
            'attention_mask':attn_mask,
            'labels':labels
        }
        